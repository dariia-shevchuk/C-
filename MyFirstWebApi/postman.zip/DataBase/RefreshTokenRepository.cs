﻿using MyFirstWebApi.Interfaces;
using MyFirstWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.DataBase
{
    public class RefreshTokenRepository : IRefreshTokenRepository
    {
        private readonly List<RefreshToken> _refreshTokens = new List<RefreshToken>();

        public void Add(RefreshToken token)
        {
            _refreshTokens.Add(token);
        }

        public RefreshToken Get(string token)
        {
            return _refreshTokens.FirstOrDefault(x => x.Token == token);
        }

        public void Update(RefreshToken token)
        {
            var current = _refreshTokens.First(t => t.Id == token.Id);
            var index = _refreshTokens.IndexOf(current);
            _refreshTokens[index] = token;
        }
    }
}