﻿using Microsoft.AspNetCore.Mvc;
using MyFirstWebApi.Interfaces;
using MyFirstWebApi.Models;

namespace MyFirstWebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IIdentitiyService _identityuService;

        public UserController(IIdentitiyService identityuService)
        {
            _identityuService = identityuService;
        }

        [HttpPost("SignUp")]
        public ActionResult SignUp([FromBody] SignUp signUp)
        {
            _identityuService.SignUp(signUp);
            return Created("", signUp);
        }

        [HttpPost("SignIn")]
        public AuthDto SignIn([FromBody] SignIn command)
        {
            return _identityuService.SignIn(command);
        }
    }
}