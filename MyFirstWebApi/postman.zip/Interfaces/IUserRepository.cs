﻿using MyFirstWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Interfaces
{
    public interface IUserRepository
    {
        User GetByEmail(string email);

        void Add(User user);

        User Get(int id);
    }
}