﻿using MyFirstWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Interfaces
{
    public interface IRefreshTokenRepository
    {
        RefreshToken Get(string token);

        void Add(RefreshToken token);

        void Update(RefreshToken token);
    }
}