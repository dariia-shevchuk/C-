﻿using MyFirstWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Interfaces
{
    public interface IRefreshTokenService
    {
        string Create(int id);

        AuthDto Use(string refreshToken);

        void Revoke(string refreshToken);
    }
}