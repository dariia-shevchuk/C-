﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Interfaces
{
    public interface IPasswordService
    {
        bool IsValid(string password1, string password2);

        string Hash(string password);
    }
}