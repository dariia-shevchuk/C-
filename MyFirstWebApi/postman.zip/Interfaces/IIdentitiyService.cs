﻿using MyFirstWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Interfaces
{
    public interface IIdentitiyService
    {
        void SignUp(SignUp signUp);

        AuthDto SignIn(SignIn signIn);
    }
}