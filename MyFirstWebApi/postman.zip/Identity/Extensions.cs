﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using MyFirstWebApi.DataBase;
using MyFirstWebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstWebApi.Identity
{
    public static class Extensions
    {
        public static void UseApSlIdentity(this IServiceCollection services)
        {
            services.AddTransient<IIdentitiyService, IdentitiyService>();
            services.AddTransient<IJwtProvider, JwtProvider>();
            services.AddTransient<IPasswordService, PasswordService>();
            services.AddTransient<IRefreshTokenService, RefreshTokenService>();
            services.AddTransient<IRefreshTokenService, RefreshTokenService>();
            services.AddTransient<IRng, Rng>();
            services.AddSingleton<IUserRepository, UserRepository>();
            services.AddSingleton<IRefreshTokenRepository, RefreshTokenRepository>();
            services.AddSingleton<IPasswordHasher<IPasswordService>, PasswordHasher<IPasswordService>>();
        }
    }
}